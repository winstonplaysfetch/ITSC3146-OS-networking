//
//  Processes.cpp
//  ITSC 3146
//
//  Created by Bahamon, Julio on 1/12/17.
//


/*
 @file Processes.cpp
 @author student name, student@uncc.edu
 @author student name, student@uncc.edu
 @author student name, student@uncc.edu
 @description: <ADD DESCRIPTION>
 @course: ITSC 3146
 @assignment: in-class activity [n]
 */


#ifndef Processes_cpp
#define Processes_cpp

#include "Processes.h"
#include <stdlib.h>


using namespace std;


// Part 1: Working With Process IDs
pid_t getProcessID(void)
{
   //a. The function must find and store the process's own process id
   pid_t p = getpid();
   //b. The function must return the process id to the calling program.
   return p;
}


// Part 2: Working With Multiple Processes
string createNewProcess(void)
{
   pid_t id = fork();
   
   // DO NOT CHANGE THIS LINE OF CODE
   process_id = id;
   
   
   if(id == -1)
   {
      return "Error creating process";
   }
   else if (id == 0)
   {
      //a. The child process must print the message I am a child process!
      std::cout << "I am a child process!\n";
      //b. The child process must then return a string with the message 
      //"I am bored of my parent, switching programs now"
      return "I am bored of my parent, switching programs now\n";
   }
   else
   {
      //c. The parent process must print the message I just became a parent!
		std::cout << "I just became a parent!\n";
		//d. The parent process must then wait until the child process terminates,
		//at which point it must return a string with the  message 
		//"My child process just terminated!" and then terminate itself.
		wait(NULL);
		return "My child process just terminated!\n";
		exit(0);
   }
}


// Part 3: Working With External Commands"
void replaceProcess(char * args[])
{
   // Spawn a process to execute the user's command.
   pid_t id = fork();

  if(id == -1)
   {
      printf("Error returning process");
   }
   else if (id == 0)
   {
      //b. The child process must then change its memory image to a different program
      execvp(args[0], args);
   }
   else
   {
      //c. Finally, in the parent process, you must make sure to invoke the
      //necessary system call to wait for the child process to terminate. 
      //Once the child terminates, exit the program.
      wait(NULL);
      exit(0);
   }

}

#endif /* TestProg_cpp */
